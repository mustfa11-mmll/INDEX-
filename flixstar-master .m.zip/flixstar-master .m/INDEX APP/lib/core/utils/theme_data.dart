import 'package:flutter/material.dart';

final ThemeData theme = ThemeData(
  brightness: Brightness.dark
);