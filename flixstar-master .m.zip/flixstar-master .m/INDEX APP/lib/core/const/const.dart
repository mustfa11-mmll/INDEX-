

bool streamMode = true;
bool showAds = true;
bool isUpdateAvailable = false;
bool forceUpdate = false;

// to show The Info Icon or not


// ADS UNIT IDS

const String bannerId1 = 'ca-app-pub-1216309845220220/2919994880'; //* REAl
const String bannerId2 = 'ca-app-pub-1216309845220220/1177536369';
const String intersititialId1 = 'ca-app-pub-1216309845220220/3693471766';
const String rewardedId1 = 'ca-app-pub-1216309845220220/9623002594'; // real

// Max Try for getting Movie or TV
const int maxRetries = 5;
