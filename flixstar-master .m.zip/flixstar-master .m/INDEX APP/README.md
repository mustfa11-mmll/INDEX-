# Movies Streaming app by VENOM82 


# API Used
 
 - TMDB API
 - VidSrc API